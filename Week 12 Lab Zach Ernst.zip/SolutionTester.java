import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class SolutionTester {
    public SolutionTester() {
    }

    public static void main(String[] args) throws IOException {
        Scanner scan = new Scanner(System.in);

        while(true) {
            while(true) {
                System.out.println("Welcome!");
                System.out.println();
                System.out.println("Please make a selection:");
                System.out.println();
                System.out.println("1: Add an employee to the database");
                System.out.println("2: Search for an employee");
                System.out.println("3: Display the information of all employess on file");
                System.out.println("4: Exit the program");
                int menu = scan.nextInt();
                int id;
                if (menu == 1) {
                    Employee empOne = new Employee();
                    EmployeeReadWrite writeEmp = new EmployeeReadWrite();
                    System.out.println("ID number of the new employee?");
                    id = scan.nextInt();
                    empOne.setempID(id);
                    System.out.println("First name of the employee?");
                    String fName = scan.next();
                    empOne.setempFname(fName);
                    System.out.println("Last name of the employee?");
                    String lName = scan.next();
                    empOne.setempLname(lName);
                    System.out.println("Salary?");
                    int salary = scan.nextInt();
                    empOne.setempSalary(salary);
                    writeEmp.writeEmployee(empOne);
                    System.out.println();
                    System.out.println("New employee succesfully added to the file");
                    System.out.println();
                    System.out.println("Redisplaying Menu");
                    System.out.println();
                } else {
                    EmployeeReadWrite obj;
                    if (menu == 2) {
                        System.out.println("Please enter the ID of the employee you wish to find");
                        id = scan.nextInt();
                        obj = new EmployeeReadWrite();
                        if (obj.readEmployee(id) == null) {
                            System.out.println("Employee not found");
                            System.out.println();
                            System.out.println("Redisplaying Menu");
                            System.out.println();
                        } else {
                            System.out.println("Search results: ");
                            System.out.println(obj.readEmployee(id));
                            System.out.println();
                            System.out.println("Redisplaying Menu");
                            System.out.println();
                        }
                    } else if (menu == 3) {
                        obj = new EmployeeReadWrite();
                        ArrayList<Employee> empList = obj.readAllEmployee();
                        System.out.println("Here is the data of all employees on file");
                        System.out.println();
                        Iterator var10 = empList.iterator();

                        while(var10.hasNext()) {
                            Employee a = (Employee)var10.next();
                            System.out.println(a.toString());
                            System.out.println();
                        }
                    } else {
                        if (menu == 4) {
                            System.out.println("Closing the Program");
                            return;
                        }

                        System.out.println("Invalid input. Please press a number from 1 to 4");
                        System.out.println();
                    }
                }
            }
        }
    }
}