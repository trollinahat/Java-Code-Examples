import java.io.IOException;

public class EmployeeLauncher {
    public EmployeeLauncher() {
    }

    public static void main(String[] args) throws IOException {
        EmployeeGUI obj = new EmployeeGUI();
        obj.setDefaultCloseOperation(3);
        obj.pack();
        obj.setVisible(true);
    }
}
