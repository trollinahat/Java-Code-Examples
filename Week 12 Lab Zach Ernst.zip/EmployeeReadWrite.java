import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class EmployeeReadWrite {
    public EmployeeReadWrite() {
    }

    public void writeEmployee(Employee obj) throws IOException {
        FileOutputStream FOS = new FileOutputStream("EmployeeData.txt", true);
        PrintWriter PW = new PrintWriter(FOS);
        PW.print(obj.toString());
        PW.close();
    }

    public Employee readEmployee(int empID) throws IOException {
        FileInputStream INFIS = new FileInputStream("EmployeeData.txt");
        Scanner Reader = new Scanner(INFIS);
        Employee obj = new Employee();

        while(Reader.hasNextLine()) {
            String FileReader = Reader.nextLine();
            String[] array = FileReader.split("\\,");
            if (array[0].equals(Integer.toString(empID))) {
                obj.setempID(Integer.parseInt(array[0]));
                obj.setempFname(array[1]);
                obj.setempLname(array[2]);
                obj.setempSalary(Integer.parseInt(array[3]));
                return obj;
            }
        }

        return null;
    }

    public ArrayList<Employee> readAllEmployee() throws IOException {
        ArrayList<Employee> EmpList = new ArrayList();
        FileInputStream fis = new FileInputStream("EmployeeData.txt");
        Scanner read = new Scanner(fis);

        while(read.hasNextLine()) {
            Employee obj = new Employee();
            String FileReader = read.nextLine();
            String[] array = FileReader.split("\\,");
            obj.setempID(Integer.parseInt(array[0]));
            obj.setempFname(array[1]);
            obj.setempLname(array[2]);
            obj.setempSalary(Integer.parseInt(array[3]));
            EmpList.add(obj);
        }

        return EmpList;
    }
}
