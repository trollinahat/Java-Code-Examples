//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

public class Employee {
    int empID;
    String empFname;
    String empLname;
    int empSalary;

    public Employee() {
    }

    public void setempID(int empID) {
        this.empID = empID;
    }

    public void setempFname(String empFname) {
        this.empFname = empFname;
    }

    public void setempLname(String empLname) {
        this.empLname = empLname;
    }

    public void setempSalary(int empSalary) {
        this.empSalary = empSalary;
    }

    public int getempID() {
        return this.empID;
    }

    public String getempFname() {
        return this.empFname;
    }

    public String getempLname() {
        return this.empLname;
    }

    public int getempSalary() {
        return this.empSalary;
    }
}