import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;

//Heavily Updated Assignment 4 Classes/Files after the assignment to update.
//This GUI works with those files

public class EmployeeGUI extends JFrame implements ActionListener {

    // Declaring Labels
    private JLabel EmpIDLabel;
    private JLabel EmpFNLabel;
    private JLabel EmpLNLabel;
    private JLabel EmpSalLabel;

    // Declaring Text Boxes
    private JTextField EmpIDText;
    private JTextField EmpFNText;
    private JTextField EmpLNText;
    private JTextField EmpSalText;

    // Declaring Buttons
    private JButton writeButton;
    private JButton cancelButton;

    EmployeeGUI() {

        GridBagConstraints positionConst = null;

        setTitle("Employee Create");

        // Labels
        EmpIDLabel = new JLabel("Employee ID:");
        EmpFNLabel = new JLabel("First Name:");
        EmpLNLabel = new JLabel("Last Name:");
        EmpSalLabel = new JLabel("Salary:");

        // Text Boxes
        EmpIDText = new JTextField(15);
        EmpIDText.setEditable(true);
        EmpFNText = new JTextField(15);
        EmpFNText.setEditable(true);
        EmpLNText = new JTextField(15);
        EmpLNText.setEditable(true);
        EmpSalText = new JTextField(15);
        EmpSalText.setEditable(true);

        // Buttons
        writeButton = new JButton("Create Employee");
        writeButton.addActionListener(this);
        cancelButton = new JButton("Clear");
        cancelButton.addActionListener(this);

        setLayout(new GridBagLayout());
        positionConst = new GridBagConstraints();

        // adding Employee ID Label
        positionConst.gridx = 0;
        positionConst.gridy = 0;

        positionConst.insets = new Insets(10, 10, 10, 10);
        add(EmpIDLabel, positionConst);

        // adding Employee ID Text Box
        positionConst.gridx = 1;
        positionConst.gridy = 0;

        positionConst.insets = new Insets(10, 10, 10, 10);
        add(EmpIDText, positionConst);

        // adding Employee First Name Label
        positionConst.gridx = 0;
        positionConst.gridy = 1;

        positionConst.insets = new Insets(10, 10, 10, 10);
        add(EmpFNLabel, positionConst);

        // adding Employee First Name Text Box
        positionConst.gridx = 1;
        positionConst.gridy = 1;

        positionConst.insets = new Insets(10, 10, 10, 10);
        add(EmpFNText, positionConst);

        // adding Employee Last Name Label
        positionConst.gridx = 0;
        positionConst.gridy = 2;

        positionConst.insets = new Insets(10, 10, 10, 10);
        add(EmpLNLabel, positionConst);

        // adding Employee Last Name Text Box
        positionConst.gridx = 1;
        positionConst.gridy = 2;

        positionConst.insets = new Insets(10, 10, 10, 10);
        add(EmpLNText, positionConst);

        // adding Employee Salary Label
        positionConst.gridx = 0;
        positionConst.gridy = 3;

        positionConst.insets = new Insets(10, 10, 10, 10);
        add(EmpSalLabel, positionConst);

        // adding Employee Salary Text Box
        positionConst.gridx = 1;
        positionConst.gridy = 3;

        positionConst.insets = new Insets(10, 10, 10, 10);
        add(EmpSalText, positionConst);

        // adding Create Employee Button
        positionConst.gridx = 4;
        positionConst.gridy = 6;

        positionConst.insets = new Insets(10, 10, 10, 10);
        add(writeButton, positionConst);

        // adding Clear Button
        positionConst.gridx = 5;
        positionConst.gridy = 6;

        positionConst.insets = new Insets(10, 10, 10, 10);
        add(cancelButton, positionConst);

    }

    @Override
    public void actionPerformed(ActionEvent event) {
        int empID;
        String empFN;
        String empLN;
        int empSal;

        Employee Temp = new Employee();
        EmployeeReadWrite obj = new EmployeeReadWrite();

        try {

            if (event.getSource() == writeButton) {
                empID = Integer.parseInt(EmpIDText.getText());
                empFN = EmpFNText.getText();
                empLN = EmpLNText.getText();
                empSal = Integer.parseInt(EmpSalText.getText());
                Temp.setempID(empID);
                Temp.setempFname(empFN);
                Temp.setempLname(empLN);
                Temp.setempSalary(empSal);

                obj.writeEmployee(Temp);
            } else if (event.getSource() == cancelButton) {
                EmpIDText.setText("");
                EmpFNText.setText("");
                EmpLNText.setText("");
                EmpSalText.setText("");
            }
        }

        catch (FileNotFoundException ioo) {
            JOptionPane.showMessageDialog(this, "FileNotFoundException found: " + ioo.getMessage());
        } catch (IOException ioe) {
            JOptionPane.showMessageDialog(this, "Input/Output Exception found: " + ioe.getMessage());
        }

    }
}