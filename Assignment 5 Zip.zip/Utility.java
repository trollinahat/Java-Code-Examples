import java.util.Random;

class Utility {
    Utility() {
    }

    public static int CalculateSum(int num) {
        int sum = 0;

        for(int count = 1; count < num; ++count) {
            sum = num + count;
        }

        return sum;
    }

    public static int CalculateFactorial(int n1) {
        int fact = 1;
        if (n1 == 0) {
            return 1;
        } else {
            for(int i = 2; i <= n1; ++i) {
                fact *= i;
            }

            return fact;
        }
    }

    public static int GenerateRandom(int n2) {
        Random RandyMarsh = new Random();
        int count1 = 0;

        for(int i = 1; i <= n2; ++i) {
            int n = RandyMarsh.nextInt(10) + 1;
            if (n == 7) {
                ++count1;
            }
        }

        return count1;
    }

    public static double FindAverage(double n3) {
        double average = 0.0D;
        double count = 0.0D;

        for(double i = 1.0D; i <= n3; ++i) {
            average += i;
            ++count;
        }

        average /= count + 1.0D;
        return average;
    }
}