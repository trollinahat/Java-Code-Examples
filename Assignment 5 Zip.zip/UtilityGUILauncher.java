import javax.swing.*;
import java.io.IOException;

public class UtilityGUILauncher {
    public UtilityGUILauncher() {
    }

        public static void main (String[]args) throws IOException {
            UtilityGUI obj = new UtilityGUI();
            obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            obj.pack();
            obj.setVisible(true);

        }
    }
