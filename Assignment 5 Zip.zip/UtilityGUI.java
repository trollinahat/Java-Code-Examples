import javafx.scene.control.Spinner;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Iterator;

public class UtilityGUI extends JFrame implements ActionListener {

    //Declaring Fields, Labels and Buttons
    private JLabel lblUserInput;
    private JLabel lblResult;
    private JSpinner spnUserInput;
    private JTextArea txtResult;
    private JButton btncalcSum;
    private JButton btncalcFactorial;
    private JButton btnGenRand;
    private JButton btnFindAverage;
    private JButton btnClear;

    UtilityGUI() { //GUI design goes here

        GridBagConstraints positionConst = null;

        setTitle("Utility User Interface");

        //Labels
        lblUserInput = new JLabel("User Input");
        lblResult = new JLabel("Result");

        //Spinner
        SpinnerNumberModel obj = new SpinnerNumberModel(20, 0, 50, 1);
        spnUserInput = new JSpinner(obj);

        //Result Text Box
        txtResult = new JTextArea(1, 20);

        //Buttons
        btncalcSum = new JButton("Calculate Sum");
        btncalcSum.addActionListener(this);
        btncalcFactorial = new JButton("Calculate Factorial");
        btncalcFactorial.addActionListener(this);
        btnGenRand = new JButton("Generate Random");
        btnGenRand.addActionListener(this);
        btnFindAverage = new JButton("Find Average");
        btnFindAverage.addActionListener(this);
        btnClear = new JButton("Clear");
        btnClear.addActionListener(this);

        setLayout(new GridBagLayout());
        positionConst = new GridBagConstraints();

        //adding User Input Label
        positionConst.gridx = 0;
        positionConst.gridy = 0;

        positionConst.insets = new Insets(10, 10, 10, 10);
        add(lblUserInput, positionConst);

        //adding UserInput JSpinner
        positionConst.gridx = 1;
        positionConst.gridy = 0;

        positionConst.insets = new Insets(10, 10, 10, 10);
        positionConst.fill = GridBagConstraints.HORIZONTAL;
        add(spnUserInput, positionConst);

        //adding Result Label
        positionConst.gridx = 0;
        positionConst.gridy = 1;

        positionConst.insets = new Insets(10, 10, 10, 10);
        add(lblResult, positionConst);

        //adding Result Text Box
        positionConst.gridx = 1;
        positionConst.gridy = 1;

        positionConst.insets = new Insets(10, 10, 10, 10);
        add(txtResult, positionConst);

        //adding Calculate Sum Button
        positionConst.gridx = 1;
        positionConst.gridy = 4;

        positionConst.insets = new Insets(10, 10, 10, 10);
        add(btncalcSum, positionConst);

        //adding Calculate factorial Button
        positionConst.gridx = 2;
        positionConst.gridy = 4;

        positionConst.insets = new Insets(10, 10, 10, 10);
        add(btncalcFactorial, positionConst);

        //Adding Generate Random Button
        positionConst.gridx = 3;
        positionConst.gridy = 4;

        positionConst.insets = new Insets(10, 10, 10, 10);
        add(btnGenRand, positionConst);

        //Adding Find Average Button
        positionConst.gridx = 4;
        positionConst.gridy = 4;

        positionConst.insets = new Insets(10, 10, 10, 10);
        add(btnFindAverage, positionConst);

        //Adding Clear Button
        positionConst.gridx = 5;
        positionConst.gridy = 4;

        positionConst.insets = new Insets(10, 10, 10, 10);
        add(btnClear, positionConst);

    }

    public void actionPerformed(ActionEvent event){
        try {

            if (event.getSource() == btncalcSum) {
                int num = (Integer) spnUserInput.getValue();
                int result = Utility.CalculateSum(num);
                txtResult.setText(Integer.toString(result));
            } else if (event.getSource() == btncalcFactorial) {
                int num = (Integer) spnUserInput.getValue();
                int result = Utility.CalculateFactorial(num);
                txtResult.setText(Integer.toString(result));
            } else if (event.getSource() == btnGenRand) {
                int num = (Integer) spnUserInput.getValue();
                int result = Utility.GenerateRandom(num);
                txtResult.setText(Integer.toString(result));
            } else if (event.getSource() == btnFindAverage) {
                double num = (Integer) spnUserInput.getValue();
                double result = Utility.FindAverage(num);
                txtResult.setText(Double.toString(result));
            } else if (event.getSource() == btnClear) {
                txtResult.setText("");
            }
        }
        catch (Exception e){
            System.out.println("Something went wrong.");
        }

    }

        }
